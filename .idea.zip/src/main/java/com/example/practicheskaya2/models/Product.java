package com.example.practicheskaya2.models;

public class Product {
}
