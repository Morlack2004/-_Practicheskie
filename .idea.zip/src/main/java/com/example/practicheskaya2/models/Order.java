package com.example.practicheskaya2.models;

public class Order {
    private int id;
    private String customerName;
    private String productName;
    private int quantity;

    // Геттеры и сеттеры
}
