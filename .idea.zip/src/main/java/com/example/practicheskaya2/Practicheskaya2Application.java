package com.example.practicheskaya2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practicheskaya2Application {

    public static void main(String[] args) {
        SpringApplication.run(Practicheskaya2Application.class, args);
    }

}
