package com.example.practicheskaya2.dao;

public class ProductDao {
}
