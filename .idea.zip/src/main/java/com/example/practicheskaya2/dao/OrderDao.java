package com.example.practicheskaya2.dao;

import com.example.practicheskaya2.models.Order;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class OrderDao {
    private static int ORDER_COUNT;
    private List<Order> orders;

    {
        orders = new ArrayList<>();
    }

    public List<Order> index() {
        return orders;
    }

    public Order show(int id) {
        // Реализация поиска заказа по ID
            return null;
    }

    public void save(Order newOrder) {
        // Реализация сохранения заказа
    }

    public void update(int id, Order updatedOrder) {
        // Реализация обновления заказа по ID
    }

    public void delete(int id) {
        // Реализация удаления заказа по ID
    }
}
