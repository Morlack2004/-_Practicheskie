package com.example.practicheskaya2.controller;

public class ReviewController {
}
